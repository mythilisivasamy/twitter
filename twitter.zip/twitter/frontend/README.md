## Twitter clone using MERN

## 1.Developing backend

## 3.back end api

1. api/seed/user
   2.api/seed/teets
